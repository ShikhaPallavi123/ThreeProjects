namespace OrderSystemLibrary
{
    public interface OutputData
    {
        void Write(Order order);
    }
}
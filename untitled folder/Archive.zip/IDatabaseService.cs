namespace OrderSystemLibrary
{
    public interface IDatabaseService
    {
        bool IsDatabaseAvailable();
    }
}